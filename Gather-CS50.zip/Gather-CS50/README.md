# Gather
Final collaborative project for Harvard CS50.
## Concept
Gather is a feature packed, event organisation tool to give you peace of mind what ever your are planning next.

## How to run
On the command line, run:
`pip install -r requirements.txt`
Which will (or should) install all the dependencies.

Then, run:
`python app.py`