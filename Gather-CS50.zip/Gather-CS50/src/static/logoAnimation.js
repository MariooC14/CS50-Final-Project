$(document).ready(function () {
  let logo = document.querySelector(".logoremain");
  logo.classList.remove("gather");
});
